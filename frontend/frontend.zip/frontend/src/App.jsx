import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import './App.css';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import PageLoader from './components/PageLoader.jsx';
import { useAuth } from './hooks/useAuth.js';
import HomePage from './pages/HomePage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import CreateTripPage from './pages/CreateTripPage.jsx';
import TripsPage from './pages/TripsPage.jsx';
import TripDetailsPage from './pages/TripDetailsPage.jsx';
import ShareTripPage from './pages/ShareTripPage.jsx';
import ProfilePage from './pages/ProfilePage.jsx';
import NotFoundPage from './pages/NotFoundPage.jsx';

function App() {
  const { authLoading } = useAuth();

  if (authLoading) {
    return <PageLoader label="Checking your TravelBuddy session..." />;
  }

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-stone-950 text-stone-100">
        <Navbar />
        <main className="mx-auto flex min-h-[calc(100vh-120px)] w-full max-w-6xl flex-col px-4 py-6 sm:px-6 lg:px-8">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route
              path="/create-trip"
              element={(
                <ProtectedRoute>
                  <CreateTripPage />
                </ProtectedRoute>
              )}
            />
            <Route
              path="/trips"
              element={(
                <ProtectedRoute>
                  <TripsPage />
                </ProtectedRoute>
              )}
            />
            <Route
              path="/trips/:tripId"
              element={(
                <ProtectedRoute>
                  <TripDetailsPage />
                </ProtectedRoute>
              )}
            />
            <Route path="/trip/:shareCode" element={<ShareTripPage />} />
            <Route
              path="/profile"
              element={(
                <ProtectedRoute>
                  <ProfilePage />
                </ProtectedRoute>
              )}
            />
            <Route path="/dashboard" element={<Navigate to="/trips" replace />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
